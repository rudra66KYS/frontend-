const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://Rudra:rudranil123@cluster0.zub1pwn.mongodb.net/signin ')
.then( ()=>{
    console.log("connected");
}
)
.catch( ()=>{
    console.log("not connected");
}
) 