const mongoose = require('mongoose');

const signup_schema = new mongoose.Schema(
    {
        name:{
            type:String,
            required:true
        },
        password:{
            type:String,
            required:true
        }
    }
)

const course_model = new mongoose.model('welcome-admin', signup_schema)
module.exports = course_model; 